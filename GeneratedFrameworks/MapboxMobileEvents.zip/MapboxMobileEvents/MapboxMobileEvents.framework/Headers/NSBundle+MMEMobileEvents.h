#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSBundle (MMEMobileEvents)

+ (BOOL)mme_isExtension;

@end

NS_ASSUME_NONNULL_END
