#import <Foundation/Foundation.h>

@interface MMECategoryLoader : NSObject

+ (void)loadCategories;

@end
